#include <iostream>
#include <cmath>

double f(double x, double y) { return y; }

int main(int argc, char** argv)
{
	double err = 1.;
	double threshold = 1e-06;
	int    n   = 0; 
	do{
		n += 1;
		double x  =0, y=1;
		double xend = 2.;
		double h  = xend / (double)n;

		for(int i=0; i<n; i++) {
			double k1 = f( x       , y          );
			double k2 = f( x+0.5*h , y+0.5*h*k1 );
			double k3 = f( x+0.5*h , y+0.5*h*k2 );
			double k4 = f( x+1. *h , y+1. *h*k3 );
			y = y + h * 1./6. * (k1+2*k2+2*k3+k4);
			x += h;
		}

		double ref = exp(xend);
		err = fabs(ref-y);
		std::cout <<"Error "   << err << ",  n="<<n << std::endl;

	} while(err>threshold); 
	return 0;
}

