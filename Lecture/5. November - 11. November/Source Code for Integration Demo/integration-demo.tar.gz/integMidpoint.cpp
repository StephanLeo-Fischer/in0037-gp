#include <iostream>
#include <cmath>

double f(double x, double y) { return y; }

int main(int argc, char** argv)
{
	double err = 1.;
	double threshold = 1e-06;
	int    n   = 0; 
	do{
		n += 1;
		double x  =0, y=1;
		double xend = 2.;
		double h  = xend / (double)n;

		for(int i=0; i<n; i++) {
			double ymid = y + 0.5 * h * f(x,y);
			y = y + h * f(x+0.5*h , ymid) ;
			x += h;
		}

		double ref = exp(xend);
		err = fabs(ref-y);
		std::cout <<"Error "   << err << ",  n="<<n << std::endl;

	} while(err>threshold); 
	return 0;
}

