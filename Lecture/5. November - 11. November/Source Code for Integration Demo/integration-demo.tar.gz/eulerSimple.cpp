#include <iostream>
#include <cmath>

double f(double x, double y) { return y; }

int main(int argc, char** argv)
{
	double x=0, y=1;
	double xe = 2.;
	int    n = 20;
	double h = xe / (double)n;

	for(int i=0; i<n; i++) {
		y = y + h * f(x,y);
		x += h;
		std::cout <<"x="<<x<<" y="<<y << std::endl;
	}

	double ref = exp(xe);
	std::cout <<"Result     " << y   << std::endl;
	std::cout <<"Reference  " << ref << ", error="<< fabs(ref-y) << std::endl;

	return 0;
}

