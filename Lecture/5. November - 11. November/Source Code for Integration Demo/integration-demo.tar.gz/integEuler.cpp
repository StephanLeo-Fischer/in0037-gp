#include <iostream>
#include <cmath>

double f(double x, double y) { return y; }

int main(int argc, char** argv)
{
	double err = 1.;
	int    n = 0;

	do{
		n += 1;
		double x=0, y=1;
		double xe = 2.;
		double h = xe / (double)n;

		for(int i=0; i<n; i++) {
			y = y + h * f(x,y);
			x += h;
		}

		double ref = exp(xe);
		err = fabs(ref-y);
		std::cout <<"Error " << err << ",  n="<<n << std::endl;

	} while(err>1e-06);

	return 0;
}

